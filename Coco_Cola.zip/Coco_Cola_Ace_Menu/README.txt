COCO COLA ACE MENU

Files:
- Coco_Cola_Ace_Menu.txt  -> modified Lua source
- Chica anime frente al logo Coca-Cola.png -> fixed menu background
- CocaCola_logo_transparent.png -> top logo extracted from the supplied image

Keep the two PNG files in the same working folder/path used by the executor so getcustomasset can load them.

Changes:
- Light main UI theme
- Main title changed to fancy Unicode: 𝓒𝓸𝓬𝓸 𝓒𝓸𝓵𝓪
- Top icon uses the supplied Coca-Cola logo
- One fixed Coca-Cola anime background
- Background selector removed from Settings
- Tabs changed to dark red
- Buttons receive animated red laser borders
- Existing functionality is otherwise left intact
